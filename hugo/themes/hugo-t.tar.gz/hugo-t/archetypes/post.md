---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
author: "Author Name"
cover: "/images/cover.jpg"
tags: ["tagA", "tagB"]
date: {{ .Date }}
draft: true
---

Cut out summary from your post content here.

<!--more-->

The remaining content of your post.
